import { motion } from 'framer-motion';
import { Cog, Zap, ArrowDownToLine, ChevronRight } from 'lucide-react';
import { useCoreStore } from '../../../store/useCoreStore';
import { useUIStore } from '../../../store/useUIStore';
import { mockStations } from '../../../data/mocks/stations';
import { Button } from '../../../components/ui/Button/Button';
import { Chip } from '../../../components/ui/Chip/Chip';

export const StationSheetStub = () => {
  const { selectedStationId, startReservation, setReservationStatus } = useCoreStore();
  const setSheetState = useUIStore(s => s.setSheetState);
  
  const station = mockStations.find(s => s.id === selectedStationId);
  if (!station) return null;

  const handleReserve = () => {
    startReservation(station.id);
    setSheetState('SHEET_RESERVATION_LIVE');
    setTimeout(() => {
      if (Math.random() > 0.3) {
        setReservationStatus('SUCCESS', Date.now() + 10 * 60 * 1000);
      } else {
        setReservationStatus('FAILED');
      }
    }, 1500);
  };

  const isHealthy = station.confidenceState === 'HIGH';

  return (
    <motion.div 
      id="station_sheet"
      initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }}
      style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}
    >
      <div style={{ marginBottom: -4 }}>
        <h2 id="station_header" style={{ fontSize: 24, fontWeight: 800, marginBottom: 2, letterSpacing: '-0.02em', lineHeight: 1.1 }}>
          {station.name}
        </h2>
        <div id="station_distance_hint" style={{ color: 'var(--color-text-muted)', fontSize: 15 }}>
          A {station.distanceMinutes} min andando
        </div>
      </div>

      {!isHealthy && (
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, paddingBottom: 4 }}>
          <span id="station_confidence_chip" style={{ flexShrink: 0, marginTop: 2 }}>
            <Chip label={station.confidenceLabel} trustLevel={station.confidenceState as 'MEDIUM'|'LOW'} />
          </span>
          <p id="station_confidence_copy" style={{ fontSize: 14, color: 'var(--color-text-muted)', lineHeight: 1.35, margin: 0 }}>
            {station.confidenceCopy}
          </p>
        </div>
      )}

      {/* 3 Metrics + 1 Action Tile */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px' }}>
        <div style={{ textAlign: 'center', padding: '14px 4px', backgroundColor: 'var(--color-surface-soft)', borderRadius: 'var(--radius-md)' }}>
          <Cog size={20} strokeWidth={2.5} style={{ margin: '0 auto 6px', color: 'var(--color-text-main)' }} />
          <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.03em' }}>{station.mechanicalCount}</div>
        </div>
        <div style={{ textAlign: 'center', padding: '14px 4px', backgroundColor: 'var(--color-surface-soft)', borderRadius: 'var(--radius-md)' }}>
          <Zap size={20} strokeWidth={2.5} style={{ margin: '0 auto 6px', color: '#3B82F6' }} />
          <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.03em' }}>{station.electricCount}</div>
        </div>
        <div style={{ textAlign: 'center', padding: '14px 4px', backgroundColor: 'var(--color-surface-soft)', borderRadius: 'var(--radius-md)' }}>
          <ArrowDownToLine size={20} strokeWidth={2.5} style={{ margin: '0 auto 6px', color: 'var(--color-text-main)' }} />
          <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.03em' }}>{station.dockCount}</div>
        </div>
        
        {/* 4th Tile: Destination Action */}
        <div 
          onClick={() => setSheetState('SHEET_STATION_INSPECT')}
          style={{ 
            display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', 
            padding: '14px 4px', backgroundColor: 'transparent', border: '1px solid var(--color-border)', 
            borderRadius: 'var(--radius-md)', cursor: 'pointer', transition: 'background-color 0.2s ease'
          }}
          onMouseEnter={(e) => e.currentTarget.style.backgroundColor = 'var(--color-surface-soft)'}
          onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
        >
          <ChevronRight size={24} style={{ color: 'var(--color-text-main)', marginBottom: 4 }} />
          <div style={{ fontSize: 12, fontWeight: 700, textAlign: 'center', lineHeight: 1.1, color: 'var(--color-text-main)' }}>Estado</div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginTop: 8 }}>
        <Button id="station_cta_reserve" fullWidth variant="secondary" onClick={handleReserve} disabled={station.mechanicalCount === 0 && station.electricCount === 0}>
          Reservar bici
        </Button>
        <Button id="station_cta_pickup" fullWidth variant="primary" onClick={() => setSheetState('SHEET_PICKUP_MODE')} disabled={station.mechanicalCount === 0 && station.electricCount === 0}>
          Coger bici
        </Button>
      </div>
    </motion.div>
  );
};
